int GND = 4;
int RED = 3;
int GREEN = 5;
int BLUE = 6;

int ido = 500;
void setup() {
  for (int led = 3; led <= 6; led++) {
    pinMode(led, OUTPUT);
  }
  digitalWrite(GND, LOW);
  Serial.begin(9600);
//  Serial.print("RED=");
  szintelen();
}

void loop() {

  if (Serial.available()>0) {
    int ertek = Serial.parseInt();
    Serial.print("RED");
    Serial.print(" = ");
    Serial.println(ertek);
    szin(pin, ertek);
  }
}

void szin(int pin, int ertek) {
  analogWrite(pin, ertek);
}

void szintelen() {
  analogWrite(RED, 0);
  analogWrite(GREEN, 0);
  analogWrite(BLUE, 0);
}