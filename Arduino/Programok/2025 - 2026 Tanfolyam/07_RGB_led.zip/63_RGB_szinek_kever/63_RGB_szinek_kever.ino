int GND = 4;
int RED = 3;
int GREEN = 5;
int BLUE = 6;

int ido = 500;
void setup() {
  for (int led = 3; led <= 6; led++) {
    pinMode(led, OUTPUT);
  }
  digitalWrite(GND, LOW);
}

void loop() {
  szinkever(RED, BLUE);
  delay(ido);
  szin_kikapcsol();
  szinkever(RED, GREEN);
  delay(ido);
  szin_kikapcsol();
  szinkever(GREEN, BLUE);
  delay(ido);
  szin_kikapcsol();
}
void szinkever(int szin1, int szin2){
  digitalWrite(szin1, HIGH);
  digitalWrite(szin2, HIGH);
}

void szin_kikapcsol(){
  digitalWrite(RED, LOW);
  digitalWrite(GREEN, LOW);
  digitalWrite(BLUE, LOW);
}
