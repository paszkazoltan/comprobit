int GND = 4;
int RED = 3;
int GREEN = 5;
int BLUE = 6;


int ido = 500;
void setup() {
  for (int led = 3; led <= 6; led++) {
    pinMode(led, OUTPUT);
  }
  digitalWrite(GND, LOW);
}

void loop() {
  digitalWrite(RED, HIGH);
  delay(ido);
  digitalWrite(RED, LOW);

  digitalWrite(BLUE, HIGH);
  delay(ido);
  digitalWrite(BLUE, LOW);

  digitalWrite(GREEN, HIGH);
  delay(ido);
  digitalWrite(GREEN, LOW);
}
