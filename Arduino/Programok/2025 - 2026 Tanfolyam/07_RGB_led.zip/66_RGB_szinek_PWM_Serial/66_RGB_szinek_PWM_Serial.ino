int GND = 4;
int RED = 3;
int GREEN = 5;
int BLUE = 6;
int k = 0;
bool valtozas = False;

int ido = 500;
void setup() {
  for (int led = 3; led <= 6; led++) {
    pinMode(led, OUTPUT);
  }
  digitalWrite(GND, LOW);
  Serial.begin(9600);

  szintelen();
}

void loop() {
  szin_beolvas();
}

void szin(int pin, int ertek) {
  analogWrite(pin, ertek);
}

void szintelen() {
  analogWrite(RED, 0);
  analogWrite(GREEN, 0);
  analogWrite(BLUE, 0);
}

void szin_beolvas() {
  if (k % 3 == 0) {
    Serial.print("RED=");     
    if (Serial.available() > 0) {
      int ertek = Serial.parseInt();
      Serial.println(ertek);
      szin(RED, ertek);        
      k++;   
    }
  }
  else if (k % 3 == 1) {
    Serial.print("GREEN=");
    if (Serial.available() > 0) {
      int ertek = Serial.parseInt();
      Serial.println(ertek);
      szin(GREEN, ertek);   
      k++;   
    }
  }
  else {
    Serial.print("BLUE=");
    if (Serial.available() > 0) {
      int ertek = Serial.parseInt();
      Serial.println(ertek);
      szin(BLUE, ertek);   
      k++;   
    }
  }
}