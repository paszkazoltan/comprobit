#define Red 13
#define Yellow 12
#define Green 11
#define Time 1000  //egysegido

void setup() {
  pinMode(Red, OUTPUT);
  pinMode(Yellow, OUTPUT);
  pinMode(Green, OUTPUT);
}
void loop() {
  for (int i = 1; i <= 5; i++) {
    normal();
  }

  for (int i = 1; i <= 3; i++) {
    alarm();
  }
}

void normal() {
  red_ON();  // kapcsoljuk be Piros-at
  delay(3 * Time);
  yellow_ON();  // tartalmazza a piros kikapcsolasa
  delay(Time);
  green_ON();
  delay(5 * Time);
}

void alarm() {
  blank();  // kapcsoljon ki mindent
  delay(Time);
  yellow_ON();  // kapcsold fel a sargat
  delay(Time);
}

void red_ON() {
  digitalWrite(Red, HIGH);
  digitalWrite(Yellow, LOW);
  digitalWrite(Green, LOW);
}

void yellow_ON() {
  digitalWrite(Red, LOW);
  digitalWrite(Yellow, HIGH);
  digitalWrite(Green, LOW);
}
void green_ON() {
  digitalWrite(Red, LOW);
  digitalWrite(Yellow, LOW);
  digitalWrite(Green, HIGH);
}

void blank() {
  digitalWrite(Red, LOW);
  digitalWrite(Yellow, LOW);
  digitalWrite(Green, LOW);
}
