#define Red 13
#define Yellow 12
#define Green 11
#define Time 1000  //egysegido

void setup() {
  pinMode(Red, OUTPUT);
  pinMode(Yellow, OUTPUT);
  pinMode(Green, OUTPUT);
}

void loop() {
  digitalWrite(Red, HIGH);  // kapcsoljuk be Piros-at
  delay(3 * Time);
  digitalWrite(Red, LOW);
  digitalWrite(Yellow, HIGH);
  delay(Time);
  digitalWrite(Yellow, LOW);
  digitalWrite(Green, HIGH);
  delay(5 * Time);
  digitalWrite(Green, LOW);
}
