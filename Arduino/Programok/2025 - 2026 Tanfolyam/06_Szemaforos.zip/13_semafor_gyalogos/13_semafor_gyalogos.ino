#define Red 13
#define Yellow 12
#define Green 11

#define GND 3
#define Red_gy 6
#define Green_gy 4

#define Time 1000  //egysegido

void setup() {
  pinMode(Red, OUTPUT);
  pinMode(Yellow, OUTPUT);
  pinMode(Green, OUTPUT);
  pinMode(GND, OUTPUT);
  pinMode(Red_gy, OUTPUT);
  pinMode(Green_gy, OUTPUT);
  digitalWrite(GND, LOW);
}
void loop() {
  for (int i = 1; i <= 5; i++) {
    normal();
  }

  for (int i = 1; i <= 3; i++) {
    alarm();
  }
}

void normal() {
  red_ON();  // kapcsoljuk be Piros-at
  delay(3 * Time);
  yellow_ON();  // tartalmazza a piros kikapcsolasa
  delay(Time);
  green_ON();
  delay(5 * Time);
}

void alarm() {
  blank();  // kapcsoljon ki mindent
  delay(Time);
  yellow_ON();  // kapcsold fel a sargat
  delay(Time);
}

void red_ON() {
  digitalWrite(Red, HIGH);
  digitalWrite(Red_gy, LOW);
  digitalWrite(Yellow, LOW);
  digitalWrite(Green, LOW);
  digitalWrite(Green_gy, HIGH);
}

void yellow_ON() {
  digitalWrite(Red, LOW);
  digitalWrite(Red_gy, HIGH);
  digitalWrite(Yellow, HIGH);
  digitalWrite(Green, LOW);
  digitalWrite(Green_gy, LOW);
}
void green_ON() {
  digitalWrite(Red, LOW);

  digitalWrite(Yellow, LOW);
  digitalWrite(Green, HIGH);
}

void blank() {
  digitalWrite(Red, LOW);
  digitalWrite(Yellow, LOW);
  digitalWrite(Green, LOW);
}
