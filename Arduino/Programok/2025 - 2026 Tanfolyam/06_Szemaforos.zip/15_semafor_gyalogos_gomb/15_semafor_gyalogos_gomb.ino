#define Red 13
#define Yellow 12
#define Green 11
#define Gomb 2
#define GND 3
#define Red_gy 6
#define Green_gy 4

#define Time 1000  //egysegido
int gomb_allapot;

void setup() {
  pinMode(Red, OUTPUT);
  pinMode(Yellow, OUTPUT);
  pinMode(Green, OUTPUT);
  pinMode(GND, OUTPUT);
  pinMode(Red_gy, OUTPUT);
  pinMode(Green_gy, OUTPUT);
  digitalWrite(GND, LOW);
  pinMode(Gomb, INPUT_PULLUP);  // input de felhuzo ellenalas +5V
}
void loop() {
  blank();
  LED_ON(Green);
  LED_ON(Red_gy);
  gomb_allapot = digitalRead(Gomb);
  if (gomb_allapot == 0){ // le van nyomva a gomb
    delay(Time);
    normal();
  }
}

void normal() {
  blank();
  LED_ON(Red);  // kapcsoljuk be Piros-at
  LED_ON(Green_gy);
  delay(3 * Time);
  LED_ON(Yellow);  // tartalmazza a piros kikapcsolasa
  alarm(Green_gy);// pillogjon a gyalogos zold 3x
  alarm(Green_gy);
  alarm(Green_gy);
  delay(Time);
  blank();
  LED_ON(Green);
  LED_ON(Red_gy);
  delay(5 * Time);
}

void alarm(int led) {
  digitalWrite(led, HIGH); 
  delay(Time/2);
  digitalWrite(led, LOW); 
  delay(Time/2);
}

void LED_ON(int led) {
  //  blank(); // nem hajtodik vegre
  digitalWrite(led, HIGH);
}

void blank() {
  digitalWrite(Red, LOW);
  digitalWrite(Yellow, LOW);
  digitalWrite(Green, LOW);
  digitalWrite(Red_gy, LOW);
  digitalWrite(Green_gy, LOW);
}
