int ido = 100;
void setup() {
  // initialize digital pin LED as an output.
  for(int i=1; i<=13; i++){ // ismeteld 1 - 13-ig
    pinMode(i, OUTPUT); // 1, 2, 3 .... 13
    digitalWrite(i, LOW);
  }
 
}


void loop() {
  // novekvo
  for(int i=1; i<=13; i++){ // ismeteld 1 - 13-ig
    digitalWrite(i, HIGH); // kapcsold fel az i-ik  ledet
    delay(ido); 

  }
  // csokkeno
   for(int i=13; i>=1; i--){ // ismeteld 1 - 13-ig
    digitalWrite(i, LOW); // kapcsold fel az i-ik  ledet
    delay(ido); 

   }               
}
