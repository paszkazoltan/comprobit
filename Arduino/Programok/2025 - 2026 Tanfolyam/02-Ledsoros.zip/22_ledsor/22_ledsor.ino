int LED1 = 1; // 1-13
int LED2 = 10; // 1-13
int ido = 200;
void setup() {
  // initialize digital pin LED as an output.
  pinMode(LED1, OUTPUT);
  pinMode(LED2, OUTPUT);
}


void loop() {
  digitalWrite(LED1, HIGH);  
  digitalWrite(LED2, LOW);  
  delay(ido);                     
  digitalWrite(LED1, LOW);   
  digitalWrite(LED2, HIGH);   
  delay(ido);                      
}
