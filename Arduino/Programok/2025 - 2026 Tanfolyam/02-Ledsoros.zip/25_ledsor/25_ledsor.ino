// paros es paratlan ledek valtakoznak
int ido = 200;
int ledek_szama = 12;
void setup() {
  // initialize digital pin LED as an output.
  for (int i = 1; i <= ledek_szama; i++) {  // ismeteld 1 - 13-ig
    pinMode(i, OUTPUT);            // 1, 2, 3 .... 13
    digitalWrite(i, LOW);
  }
}

void loop() {
  // paros led fel
  for (int i = 1; i <= ledek_szama; i++) {  // ismeteld 1 - 12-ig
    if (i % 2 == 0) {
      digitalWrite(i, HIGH);  // kapcsold fel az i-ik  ledet
    } else {
      digitalWrite(i, LOW);  // kapcsold le az i-ik  ledet
    }
  }
  delay(ido);
  for (int i = 1; i <= ledek_szama; i++) {  // ismeteld 1 - 12-ig
    if (i % 2 == 1) {
      digitalWrite(i, HIGH);  // kapcsold fel az i-ik  ledet
    } else {
      digitalWrite(i, LOW);  // kapcsold le az i-ik  ledet
    }
  }
  delay(ido);
}
