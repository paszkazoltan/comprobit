#define Led 10
#define Gomb 12
#define Buzzer 8

int allapotGomb;

void setup() {
  // put your setup code here, to run once:
  pinMode(Led, OUTPUT);
  pinMode(Gomb, INPUT);
  pinMode(Buzzer, OUTPUT);
}

void loop() {
  // put your main code here, to run repeatedly:
  allapotGomb = digitalRead(Gomb);
  if (allapotGomb == HIGH) {
    digitalWrite(Led, HIGH);
    tone(Buzzer, 200);
  } else {
    digitalWrite(Led, LOW);
    noTone(Buzzer);
  }
  delay(20);
}
