#define Led 10
#define Gomb 12

int allapotGomb;

void setup() {
  // put your setup code here, to run once:
  pinMode(Led, OUTPUT);
  pinMode(Gomb, INPUT);
}

void loop() {
  // put your main code here, to run repeatedly:
  allapotGomb = digitalRead(Gomb);
  if (allapotGomb == HIGH)
  {
    digitalWrite(Led, HIGH);
  }
  else
  {
    digitalWrite(Led, LOW);
  }
  delay(20);
}
